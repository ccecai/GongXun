/**MADE BY ME
  ******************************************************************************
  * @author   LIU_Standard
  * @version V1.0.0
  * @date    04-August-2014
  * @brief  
  * 
  ******************************************************************************
  * @attention
  * 
  ******************************************************************************
  */

/* Private Includes ----------------------------------------------------------*/
#include "comother.h"
#include "delay.h"
#include "oled.h"
#include "usart.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define -----------------------------------------------------------*/ 

#define PACK_HEADER 0X55
#define CODE_MODE   0X33
#define COLOR_MODE	0X30
//#define NONE_MODE	0X34

const uint16_t RXALL_LENGTH = 9;
#define RXDATA_LENGTH 7
#define TXPACK_LENGTH 9
#define COM_BUFFER_SIZE 450
/* Global param -------------------------------------------------------------*/
static uint8_t com_rxbuff[TXPACK_LENGTH];
static uint8_t com_txbuff[TXPACK_LENGTH];

COM_RXStatusTypeDef rx_status;
COM_TXStatusTypeDef tx_status;
//��1��Ϊ��ɫ����2��Ϊ��ɫ����3��Ϊ��ɫ
//Ȼ��������ƶ���ԭ������������涨��˳�����ν�ԭ�������ϲ����ϰ��˵���������
//ѡ��ģʽ��Ҫ���͵�����
//ԭ�Ϻʹּӹ����İ���˳��һ��
uint8_t color_send_data[7] = {0X30,0X00, 0X00,0X00,0X00,0X00,0X00};
uint8_t code_send_data[7] = {0X33,0X00, 0X00,0X00,0X00,0X00,0X00};

uint8_t rx_data[7] = {0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00};
//uint8_t move_order[6] = {};//���ϰ��˵�˳��
//uint8_t color_order[6] = {};//���ϵİڷ�˳��
//uint8_t 
/* Private functions --------------------------------------------------------*/
/* Functions -----------------------------------------------------------------*/

uint8_t PC_RecBuff[15] = {0};
uint8_t send_data[7] = {0X30, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00};//Ĭ��Ϊ��Ч����

void COM_ChooseMode(uint8_t mode)
{
	send_data[0] = mode;
	COM_SendAll(send_data);
}
uint8_t COM_GetCodeOrder(uint8_t * codeorder)
{
	OLED_CLS();
	if(rx_data[0] == CODE_MODE && rx_data[3] != 0)//�жϿ�ʼ������ֵ
	{
		
		for (int i = 0; i < 6; i++)
		{
			codeorder[i] = rx_data[i+1];
			OLED_Printf(i*12, 10, "%d", codeorder[i]);
		}
		
		return 1; //���ճɹ�
	}
	COM_SendAll(rx_data);
	OLED_RefreshGram();
	delay_ms(100);
	return 0;

}
uint8_t COM_GetColorOrder(uint8_t * order)
{
	if(rx_data[0] == COLOR_MODE && rx_data[3] != 0  && rx_data[2] != 0)//�жϿ�ʼ������ֵ
	{
		for (int i = 0; i < 6; i++)
			order[i] = rx_data[i+1];
		
		return 1;
	}
	delay_ms(1);
}

//ʹ�ô���3�������ݣ�ֻ�ᷢһ�β���ռ�úܶ�ʱ��
void COM_SendBuffer(uint8_t *p, uint16_t length)
{
	int i;
	for(i=0;i<length;i++)
	{
		USART_SendData(USART3, *p++);
		while(USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET); 
	}
}

//����3 TX PD8     RXPD9
void COM_PCInit(uint32_t bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	COM_PackInit();
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

	GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_USART3);
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_USART3);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;					
	USART_InitStructure.USART_StopBits = USART_StopBits_1;						
	USART_InitStructure.USART_Parity = USART_Parity_No;							
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;				
	USART_Init(USART3, &USART_InitStructure);

	USART_Cmd(USART3, ENABLE);
	USART_ClearFlag(USART3, USART_FLAG_TC);
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_ClearITPendingBit(USART3, USART_IT_RXNE);
}

void COM_PackInit(void)
{
	rx_status.read_flag 	  = 0;
	rx_status.read_index      = 0;
	rx_status.read_sum        = 0;
	rx_status.read_temp_index = 0;
	rx_status.rx_index        = 0;
	tx_status.data_index      = 0;
	tx_status.send_sum        = 0;
}

uint32_t err_com_data = 0;
uint8_t COM_ReadAll(uint8_t *rx_data_ptr)
{
	uint16_t 	data_index 	= 0; // �Ӵ������ݵĵط���ʼ������
	uint16_t 	data_length = 0;
	uint16_t 	loop_index; // ����ѭ��
	uint32_t 	read_ptr;

	rx_status.read_flag = 0; 

	while((int64_t)rx_status.read_index < (int64_t)(rx_status.rx_index - (RXALL_LENGTH*2)))
	{
		rx_status.read_index += RXALL_LENGTH; // ÿһ��length����������һ������������ǰ���ۼƵ�
	}

	// ��Ҫ��һ�������ſ�ʼ����
	while(rx_status.read_index <= (rx_status.rx_index - RXALL_LENGTH))
	{
		rx_status.read_temp_index = rx_status.read_index % COM_BUFFER_SIZE; // ����BUFFER, �жϻ��Զ����Ǵ�ͷ��ʼ
		data_index = rx_status.read_temp_index + 1;
		
//		OLED_Printf(8, 20, "%d, %d", rx_status.rx_index, rx_status.read_index);
//		OLED_RefreshGram();
		
		delay_ms(20); //���bugû�ҵ�
		if(com_rxbuff[rx_status.read_temp_index] == PACK_HEADER) // ��⵽��ͷ
		{
			//ͷ�ǶԵ�����
			rx_status.read_sum=0;
			for(loop_index = 0; loop_index < RXALL_LENGTH - 1; loop_index++)
			{
				if(rx_status.read_temp_index >= COM_BUFFER_SIZE)
					rx_status.read_temp_index -= COM_BUFFER_SIZE;
				rx_status.read_sum += com_rxbuff[rx_status.read_temp_index];
				rx_status.read_temp_index++;//�ô�0λ��ʼ�ӣ�ע��У��λ�ͺ�λ��һ������
			}
			
			//�����0��8λ �ھ�λΪ��
			//rx_status.read_temp_index++;
			if(rx_status.read_temp_index >= COM_BUFFER_SIZE)
				rx_status.read_temp_index -= COM_BUFFER_SIZE; //����ȡ��
			
			if(rx_status.read_sum == com_rxbuff[rx_status.read_temp_index]) // У���
			{
				read_ptr = (uint32_t)(rx_data_ptr);
				data_length = RXDATA_LENGTH;
				for(loop_index = 0; loop_index < data_length; loop_index++)
				{
					if(data_index >= COM_BUFFER_SIZE)
						data_index -= COM_BUFFER_SIZE;
					(*((uint8_t *)read_ptr)) = com_rxbuff[data_index];
					data_index++;
					read_ptr++;
				}
				err_com_data = data_index;
				rx_status.read_index += RXALL_LENGTH; //����һ�����������Ǹ�����
				rx_status.read_flag = 1;
			}
			
			else
			{
				rx_status.read_index++;
				err_com_data++;
			}
		}
		else
		{
			rx_status.read_index++;
			err_com_data++;
		}
	}
	return rx_status.read_flag;
}


void COM_SendAll(uint8_t *tx_data_ptr)
{
	int i;
	uint8_t data_bit_index = 0;
	uint8_t data_index = 1;
	uint16_t loop_index;
	com_txbuff[0] = PACK_HEADER;
	tx_status.send_sum = 0;
	
	for(loop_index = 0; loop_index < TXPACK_LENGTH - 1; loop_index++)
	{
		com_txbuff[data_index++] = tx_data_ptr[loop_index];
	}
	
	for(loop_index = 0; loop_index <= TXPACK_LENGTH - 1; loop_index++)
		 tx_status.send_sum += com_txbuff[loop_index];
	
	com_txbuff[TXPACK_LENGTH - 1] = tx_status.send_sum;
	COM_SendBuffer(com_txbuff, TXPACK_LENGTH);
}

/**
  * @brief  ��ʱ��2�����жϣ����°�ֵ
  * @param  None
  * @retval None
  */
static uint16_t circle_rx_index = 0;
uint8_t USART3_RecNum = 0;
void USART3_IRQHandler(void)
{
	uint8_t Res;
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
	{
		Res = USART_ReceiveData(USART3); 	
		 
		if(USART3_RecNum == 0 )
		{
			if(Res == 0X55) //�յ���ͷ����ʼ�ж�
			{
				com_rxbuff[0] = Res;
				USART3_RecNum = 1;
			}
			else 
			{//����
				USART3_RecNum = 0;
			}
		}

		else
		{
			if(USART3_RecNum < 9)
			{
				//������8
				com_rxbuff[USART3_RecNum++] = Res;
			}
			if(USART3_RecNum == 9)//�յ���9��
			{
				uint8_t read_sum=0;
				for(int loop_index = 0; loop_index < RXALL_LENGTH - 1; loop_index++)
				{
					read_sum += com_rxbuff[loop_index];
				}
				
				if(read_sum == com_rxbuff[8]) // У���
				{
					for(int loop_index = 0; loop_index < RXDATA_LENGTH; loop_index++)
					{
						rx_data[loop_index] = com_rxbuff[loop_index + 1];
					}
					USART3_RecNum = 0; //������յ��Ķ���
				}
				else 
				{//����
					USART3_RecNum = 0;
				}				
			}
		}
	}
	USART_ClearITPendingBit(USART3, USART_IT_RXNE);	
}

uint8_t * COM_GetRXData(void)
{
	return rx_data;
}


void COM_Debug(void)
{
	while(1)
	{
		//COM_PackInit();
		
//		COM_SendAll(send_data);
//		//
//		delay_ms(3000);
		send_data[0] = 0X33;
		COM_SendAll(send_data);
		delay_ms(500);
//		while(1)
//		{
//			COM_ReadAll(rx_data);//������
//////			send_data[0] = 0X30;
//			//COM_SendAll(rx_data);
//			printf("a:%d,%d,%d,%d,%d,%d,%d\n", rx_data[0], rx_data[1], rx_data[2], rx_data[3], rx_data[4], rx_data[5], rx_data[6]);
//			delay_ms(300);
//		}
		//delay_ms(3000);
//		while(1)
//		{
//			
//			delay_ms(300);
//		}
	}
}
